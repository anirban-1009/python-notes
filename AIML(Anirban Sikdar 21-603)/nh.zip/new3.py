a="Welcome"
print(a[3:])
print(a[-2:])
print(a[:-3])
print(len(a))
b="ecome"
f ="HDH8UHEU"
c = b.upper()
c1 = f.lower()
print(c)
#a[2] = 'e'
#print(a)
print(c1)
print(a[0:6:2])
print(a.index('o'))
print(a[2:5].upper())
x = []
x.append('a')
print(x)
#02-11-2021
