a = (1,2,3,4,4,4)
b = 1,
print(a.index(2))
print(a.count(4))
print(b)
