print("Welcome to python class")
print('-'*40)
print("Hello \t python")#TAB METHOD
print('-'*40)
print('Bye\nAIML')#NEW LINE METHOD
t = 15
a = "HITAM IS GOOD"
b = 3.14
n = True
o = 7+5j
print('-'*40)
print(t)#PRINTING PRE DEFINED VARIABLE
print('-'*40)
print(type(t))#PRINTING TYPE OF A VARIABLE
print('-'*40)
print('Hello "AIML"')#SINGLE QUOTE METHOD
print('-'*40)
print("Hello \"AIML\"")#BACKSLASH METHOD
print('-'*40)

print("DIFFERENT DATA TYPES OF PYTHON:")#DATA TYPES OF PYTHON
print(f"integer:{type(t)}")
print(f"float:{type(b)}")
print(f"string:{type(a)}")
print(f"boolean:{type(n)}")
print(f"complex:{type(o)}")
print('='*40)

p = 0b1111#BINARY NUMBER
m = 0o017#OCTAL NUMBER
y = 0xfA#HEXADECIMAL NUMBER
print("-"*10,"BINARY","-"*10)
print(p, type(p))
print("-"*10,"OCTAL","-"*10)
print(m,type(m))
print("-"*10,"HEXADECIMAL","-"*10)
print(y,type(y))
print('='*40)


#COMMENTING:)
#PTRINRUJHGDYUGDKJFHUIYFGKJAHNLKJSDHKJHD
print('-'*40)
print("Hello");print("k")
print('-'*40)

#FLOAT DATA TYPE
y = 444.68767

print(type(y))
print('-'*40)

#COMPLEX
y = 3+5j
print(type(y))
print('-'*40)

#STRING
y = "help"
print(type(y))

#AUTHOR - ANIRBAN SIKDAR
