#USER INPUTS
k = input("Enter name:")
print(k)
print(type(k))#PRINTING THE TYPE OF THE VARIABLE
print(len(k))

h = int(input("enter age:"))#ONLY ACCEPTING INT-TYPE INPUT(SUBJECT TO BE MANIPULATED!!)
print(h)
print(type(h))
print("The age is %d"%(h))#printing variables within the strings!!


#ARTHEMATIC OPERATORS

a = 9
b = 7

add = a+b
sub = a-b
mul =a*b
div = a/b
pow = a**b
onw = a//b

print(add, sub, mul,div,pow,onw)

#OPERATION PRIORITY STUFF LIKE MULTIPLE FUNCTIONS ON THE SAME LINE
t = 2*3-4/3+2**3
print(t)

#making a string out of pre-defined string which is been added and then printed
v = "Hello "
b = v + "Me!"

print(b)

#AUTHOR-ANIRBAN SIKDAR
