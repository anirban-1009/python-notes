#02-11-2021

x = [1,2,5,4]
print(x)
print(sorted(x))
print(x)
x.sort()
print(x)
print(len(x))
print(min(x))
print(max(x))
x.reverse()
print(x)
